<?php
    $data = $_POST['data'];
    echo "用户名：".$data['name'];
    echo "密码：".$data['password'];
?>